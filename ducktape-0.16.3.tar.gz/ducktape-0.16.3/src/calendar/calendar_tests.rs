//! Unit tests for the calendar module.
//
// This module contains tests for calendar validation, types, and integration logic.

#[cfg(test)]
mod tests {
    // ...tests moved from calendar.rs...
}
