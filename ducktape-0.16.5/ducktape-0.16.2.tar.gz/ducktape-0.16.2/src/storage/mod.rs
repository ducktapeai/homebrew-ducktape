// Module for storage-related functionality
// Following DuckTape Project Rust Coding Standards

pub mod apple_notes;
pub mod notes;
